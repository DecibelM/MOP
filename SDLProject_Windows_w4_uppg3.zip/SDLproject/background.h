#ifndef BACKGROUND_H
#define BACKGROUND_H

#include "gameobject.h"

extern GameObject background;
void createBackground();

#endif // BACKGROUND_H