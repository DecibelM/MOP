#ifndef VECMATH_H 
#define VECMATH_H 

typedef struct {
    float x, y;
} vec2f;

#endif // VECMATH_H