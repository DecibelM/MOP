We are using the following versions:

SDL2-2.0.5\x86_64-w64-mingw32\

SDL2_ttf-2.0.14\x86_64-w64-mingw32\

SDL2_image-2.0.1 2\x86_64-w64-mingw32


/Ulf Assarsson