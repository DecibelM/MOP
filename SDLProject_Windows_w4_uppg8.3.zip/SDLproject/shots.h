#ifndef SHOTS_H
#define SHOTS_H
#include "gameobject.h"

GameObject* createPlayerShot1(vec2f pos, vec2f dir);

#endif // SHOTS_H