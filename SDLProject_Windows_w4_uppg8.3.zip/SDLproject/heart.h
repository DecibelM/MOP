#ifndef HEART_H
#define HEART_H

void createHearts();

#endif // HEART_H