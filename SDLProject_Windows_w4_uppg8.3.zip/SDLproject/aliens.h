#ifndef ALIENS_H
#define ALIENS_H

void createAliens();

#endif // ALIENS_H