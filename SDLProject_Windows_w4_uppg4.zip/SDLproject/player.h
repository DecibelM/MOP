#ifndef PLAYER_H
#define PLAYER_H

#include "gameobject.h"

extern GameObject ship;

void createShip();

#endif // PLAYER_H