#ifndef COIN_H
#define COIN_H

void createCoins();

#endif // COIN_H